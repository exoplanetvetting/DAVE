
def print_b():
    "Prints b."
    print 'b'

def print_a():
    "Prints a."
    print 'a'

c = 2
d = 2


